#!/bin/sh
scrapy crawl yingjiesheng
scrapy crawl nwpujob

