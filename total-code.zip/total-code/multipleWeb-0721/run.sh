#!/bin/sh
#
# ---------------------------------------------------------------------
# PyCharm startup script.
# ---------------------------------------------------------------------

scrapy crawl yingjiesheng && scrapy crawl nwpujob

